/*
* Student Name
* Project Name
* Date
* Description
*/

/** Global Variables */


function setup() {
  let sketch = createCanvas(600, 400);
}


function draw() {
  background(200);
  
}
